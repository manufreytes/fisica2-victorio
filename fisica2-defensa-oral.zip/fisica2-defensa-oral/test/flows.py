import json
from playwright.sync_api import sync_playwright
BASE='http://localhost:8123/index.html'
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    ctx=b.new_context(viewport={'width':1280,'height':900}, permissions=[])
    pg=ctx.new_page()
    pg.on('console',lambda m: errs.append((m.type,m.text)) if m.type in('error','warning') else None)
    pg.on('pageerror',lambda e: errs.append(('pageerror',str(e))))
    # 1) KaTeX errors on every unit/route
    tot=0
    for i in range(1,13):
        pg.goto(BASE+f'#/unidad/{i}'); pg.wait_for_timeout(250)
        n=pg.evaluate("()=>document.querySelectorAll('.katex-error').length")
        # open all details to render keys
        pg.evaluate("()=>document.querySelectorAll('details').forEach(d=>d.open=true)"); 
        pg.evaluate("()=>{renderMathInElement(document.body,{delimiters:[{left:'$$',right:'$$',display:true},{left:'$',right:'$',display:false}],throwOnError:false})}")
        n2=pg.evaluate("()=>document.querySelectorAll('.katex-error').length")
        raw=pg.evaluate("()=>(document.body.innerText.match(/\\$[^$]{1,60}\\$/g)||[]).slice(0,3)")
        if n or n2 or raw: print('unit',i,'katex errors',n,n2,'raw$',raw)
        tot+=n2
    # deducciones, cards, vf, tribunal keys, bridges: render math in a scratch div and count errors
    res=pg.evaluate("""()=>{const bad=[];const d=document.createElement('div');document.body.appendChild(d);
      const chk=(s,w)=>{d.innerHTML=s;renderMathInElement(d,{delimiters:[{left:'$$',right:'$$',display:true},{left:'$',right:'$',display:false}],throwOnError:false});
        if(d.querySelector('.katex-error')||/\\$/.test(d.textContent))bad.push(w+': '+s.slice(0,90));};
      F2.units.forEach(u=>{u.cards.forEach((c,i)=>{chk(c[0],'u'+u.id+' card f'+i);chk(c[1],'u'+u.id+' card b'+i)});
        u.deduccion.pasos.forEach((s,i)=>chk(s,'u'+u.id+' ded'+i));u.vf.forEach((v,i)=>{chk(v[0],'u'+u.id+' vf'+i);chk(v[2],'u'+u.id+' vfx'+i)});
        u.tribunal.forEach((q,i)=>{chk(q.q,'u'+u.id+' q'+i);q.k.forEach((k,j)=>chk(k,'u'+u.id+' q'+i+' k'+j));if(q.err)chk(q.err,'u'+u.id+' q'+i+' err')});
        u.formulas.forEach((f,i)=>{chk(f[1],'u'+u.id+' f'+i);if(f[2])chk(f[2],'u'+u.id+' fn'+i)});chk(u.idea,'idea'+u.id);chk(u.resumen,'res'+u.id)});
      F2.bridges.forEach((b,i)=>b.k.forEach((k,j)=>chk(k,'bridge'+i+'.'+j)));return bad}""")
    print('MATH PROBLEMS:',len(res)); [print('  ',r) for r in res]
    # 2) flujo bolillero completo
    pg.goto(BASE+'#/bolillero'); pg.wait_for_timeout(500)
    pg.select_option('#pickU','4'); pg.click('#spin'); pg.wait_for_selector('#go',timeout=8000); pg.click('#go')
    for k in range(4):
        pg.wait_for_selector('#ans'); pg.fill('#ans','eh la ley dice que o sea el flujo '*3); pg.click('#done'); pg.wait_for_selector('#review input')
        boxes=pg.query_selector_all('#review input'); 
        for j,bx in enumerate(boxes):
            if j%2==0: bx.check()
        pg.click('#next')
    pg.wait_for_selector('.score'); print('SUMMARY:',pg.inner_text('.score'), pg.inner_text('h2'))
    pg.screenshot(path='/tmp/shots/summary.png')
    pg.click('#mk'); pg.wait_for_timeout(300)
    # 3) mazo
    pg.goto(BASE+'#/entrenar/mazo'); pg.wait_for_selector('#show'); pg.click('#show'); pg.keyboard.press('3'); pg.wait_for_selector('#show')
    pg.keyboard.press('Space'); pg.keyboard.press('1'); 
    # 4) deduccion: armar en orden correcto
    pg.goto(BASE+'#/entrenar/deduccion?u=5'); pg.wait_for_selector('[data-p]')
    order=pg.evaluate("()=>F2.units[4].deduccion.pasos.length")
    for i in range(order):
        # elegir el paso con índice i (data-p=i)
        pg.click(f'[data-p="{i}"]')
    pg.click('#check'); pg.wait_for_timeout(200); print('DED:',pg.inner_text('#msg')[:60])
    # 5) vf
    pg.goto(BASE+'#/entrenar/vf'); pg.wait_for_selector('[data-a]'); pg.click('[data-a="1"]'); pg.wait_for_selector('#nx'); pg.click('#nx')
    # 6) constelacion: click arista
    pg.goto(BASE+'#/'); pg.wait_for_timeout(300); pg.click('.edge.hit[data-i="5"]',force=True); print('BRIDGE:',pg.inner_text('#bridgebox')[:80].replace('\n',' | '))
    # 7) progreso con datos
    pg.goto(BASE+'#/progreso'); pg.fill('#exam','2026-12-10'); pg.wait_for_timeout(300); pg.screenshot(path='/tmp/shots/progreso2.png',full_page=True)
    # 8) movil
    m=b.new_context(viewport={'width':390,'height':800},is_mobile=True,has_touch=True).new_page()
    m.on('pageerror',lambda e: errs.append(('mobile pageerror',str(e))))
    for h,n in [('#/','m_home'),('#/lab/lente','m_lente'),('#/bolillero','m_bol'),('#/unidad/7','m_u7')]:
        m.goto(BASE+h); m.wait_for_timeout(500); m.screenshot(path=f'/tmp/shots/{n}.png')
    b.close()
print('ERRORS:',json.dumps(errs,ensure_ascii=False)[:2000])
