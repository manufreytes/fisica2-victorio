import sys, json
from playwright.sync_api import sync_playwright
BASE='http://localhost:8123/index.html'
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900})
    pg.on('console',lambda m: errs.append(('console',m.type,m.text)) if m.type in('error','warning') else None)
    pg.on('pageerror',lambda e: errs.append(('pageerror',str(e))))
    def go(h,name,wait=600):
        pg.goto(BASE+h); pg.wait_for_timeout(wait); pg.screenshot(path=f'/tmp/shots/{name}.png',full_page=False)
    go('#/','home')
    go('#/unidades','unidades')
    go('#/unidad/3','unidad3')
    go('#/bolillero','bolillero',900)
    for s in ['campo','lorentz','transitorios','alternador','rlc','lente','young']:
        go('#/lab/'+s, 'sim_'+s, 2300)
    go('#/entrenar/mazo','mazo'); go('#/entrenar/deduccion','ded'); go('#/entrenar/vf','vf'); go('#/progreso','progreso')
    # katex errors
    bad=pg.evaluate("()=>document.querySelectorAll('.katex-error').length")
    print('katex-error nodes on last page:',bad)
    b.close()
print('ERRORS:',json.dumps(errs,indent=1,ensure_ascii=False)[:3000])
