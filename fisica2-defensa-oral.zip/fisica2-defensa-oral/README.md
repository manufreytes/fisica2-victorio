# Física 2 · Defensa Oral

Plataforma de estudio y **simulador de defensa oral** para Física 2 (electromagnetismo y óptica, FCEFyN-UNC, programa 10-04067), organizada según las 12 unidades del programa y apoyada en *Sears–Zemansky–Young–Freedman, Física Universitaria, vol. 2*.

Es un sitio **100 % estático** (HTML + CSS + JS, sin build, sin servidor, sin dependencias externas en tiempo de ejecución: KaTeX y tipografías están incluidos en `site/vendor`). El progreso se guarda en el navegador de cada persona (localStorage) y funciona sin conexión.

## Qué incluye
- **Bolillero + tribunal**: sacás una bolilla y te hacen 4 preguntas (exposición libre, definición/deducción, aplicación/cruzada, pregunta puente). Cronómetro, dictado por voz (es-AR), pizarra, métrica de muletillas, lista de *puntos clave* esperados, autoevaluación con la rúbrica CG1/CG4/CG9 y umbral del 60 %. Lo que falla se convierte en tarjetas.
- **Constelación de Maxwell**: mapa de 21 conexiones entre unidades; cada una es un “relacioná X con Y” practicable.
- **Unidades**: resumen, fórmulas, preguntas de tribunal con claves y error típico, puentes, TPL de laboratorio.
- **Entrenar**: mazo con repaso espaciado, *armá la deducción* (ordenar pasos) y verdadero/falso con trampa.
- **Laboratorio**: 7 simuladores (campo y equipotenciales, partícula en E y B, transitorios RC/RL con ajuste semilog tipo TPL 7, alternador, RLC con fasores y resonancia, lente delgada, Young/difracción).
- **Progreso**: radar por unidad, plan de ataque según fecha de examen, exportar/importar datos.

## Desplegar

### GitHub Pages
1. Subí esta carpeta a un repositorio nuevo (rama `main`).
2. En *Settings → Pages* elegí **Source: GitHub Actions**.
3. Cada push a `main` ejecuta `.github/workflows/pages.yml` y publica `site/`.

### Cloudflare Pages
*Workers & Pages → Create → Pages → Connect to Git* → elegí el repo. **Build command**: vacío. **Build output directory**: `site`.
(Alternativa sin Git: `npx wrangler pages deploy site`.)

### Local
```bash
cd site && python3 -m http.server 8000   # y abrí http://localhost:8000
```
También abre con doble clic en `site/index.html` (sin service worker).

## Editar o ampliar el contenido
Cada unidad es un archivo en `site/js/content/uNN.js` con `resumen`, `formulas`, `tribunal`, `cards`, `deduccion` y `vf`. Las fórmulas usan LaTeX entre `$…$` (se escriben con `R\`…\`` para no duplicar barras). Los puentes están en `content/bridges.js` y los simuladores en `js/sims.js`.

## Pruebas
`test/smoke.py` y `test/flows.py` (Playwright) recorren todas las vistas, validan que no haya errores de consola ni de KaTeX y simulan una defensa completa.

## Nota sobre contenido
Los resúmenes, preguntas y claves son material de estudio original, escrito a partir del programa de la cátedra; no reproducen texto del libro. Las referencias de capítulo corresponden a la 12.ª edición en español del vol. 2 y pueden variar según la edición. **Contrastalo con tu bibliografía y con lo que dicta tu cátedra.**
